# Principles of Software Engineering

This repository contains the sample code and open response questions for the testing and enterprise architecture portions of the course. Please see the "questions" folder for the open response questions.

# Assignment Weights & Due Dates

The assignments will be weighted equally. The instructor will release assignments through GitHub throughout the semester as relevant material is covered.
